# Scenario Planner Image

Please save your scenario planner screenshot as:
`scenario-planner.png`

This image will be displayed in the Scenario Planner modal when accessed through:
- The "+" menu > "Scenario Planner..." option in the chat input
- Any other scenario planner triggers in the app

The modal will automatically scale the image to fit within 95% of the viewport width and height.